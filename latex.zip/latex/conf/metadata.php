<?php

$meta['latex_path'] = array('string');
$meta['dvips_path'] = array('string');
$meta['convert_path'] = array('string');
$meta['identify_path'] = array('string');
$meta['tmp_dir'] = array('string');
$meta['image_format'] = array('string');
$meta['colour'] = array('string');
$meta['density'] = array('numeric');
